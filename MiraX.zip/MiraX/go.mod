module mirax

go 1.21
