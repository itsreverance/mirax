package handlers

import (
	"fmt"
	"net"
)

// PlanInfo holds subscription plan details
type PlanInfo struct {
	Name        string
	MaxDuration int
	DailyLimit  int
	Methods     string
	Price       string
}

// Available plans
var Plans = []PlanInfo{
	{
		Name:        "VIP",
		MaxDuration: 3600,
		DailyLimit:  0,
		Methods:     "All methods",
		Price:       "Contact owner",
	},
	{
		Name:        "PREMIUM",
		MaxDuration: 1200,
		DailyLimit:  500,
		Methods:     "Most methods (no GRE/DNS)",
		Price:       "Contact owner",
	},
	{
		Name:        "USER",
		MaxDuration: 300,
		DailyLimit:  50,
		Methods:     "UDP, TCP, SYN only",
		Price:       "Free",
	},
}

// GetPlan returns plan info by name
func GetPlan(name string) *PlanInfo {
	for _, p := range Plans {
		if p.Name == name {
			return &p
		}
	}
	return nil
}

// ShowPlan displays all available plans
func ShowPlan(conn net.Conn) {
	conn.Write([]byte("\n"))

	for _, p := range Plans {
		conn.Write([]byte(fmt.Sprintf("%s\n", p.Name)))
		conn.Write([]byte(fmt.Sprintf("  Max Duration: %ds\n", p.MaxDuration)))
		if p.DailyLimit == 0 {
			conn.Write([]byte("  Daily Limit:  Unlimited\n"))
		} else {
			conn.Write([]byte(fmt.Sprintf("  Daily Limit:  %d\n", p.DailyLimit)))
		}
		conn.Write([]byte(fmt.Sprintf("  Methods:      %s\n", p.Methods)))
		conn.Write([]byte(fmt.Sprintf("  Price:        %s\n", p.Price)))
		conn.Write([]byte("\n"))
	}
}

// ShowUserPlan displays the user's current plan
func ShowUserPlan(conn net.Conn, username, plan string) {
	p := GetPlan(plan)
	if p == nil {
		conn.Write([]byte(fmt.Sprintf("\n[!] Plan '%s' not found.\n\n", plan)))
		return
	}

	conn.Write([]byte("\n"))
	conn.Write([]byte(fmt.Sprintf("User: %s\n", username)))
	conn.Write([]byte(fmt.Sprintf("Plan: %s\n", p.Name)))
	conn.Write([]byte(fmt.Sprintf("  Max Duration: %ds\n", p.MaxDuration)))
	if p.DailyLimit == 0 {
		conn.Write([]byte("  Daily Limit:  Unlimited\n"))
	} else {
		conn.Write([]byte(fmt.Sprintf("  Daily Limit:  %d\n", p.DailyLimit)))
	}
	conn.Write([]byte(fmt.Sprintf("  Methods:      %s\n", p.Methods)))
	conn.Write([]byte("\n"))
}