package handlers

import (
	"net"
)

// OwnerInfo holds owner details
type OwnerInfo struct {
	Name     string
	GitHub   string
	Telegram string
	Discord  string
	Website  string
	Email    string
}

// GetOwnerInfo returns the owner information
func GetOwnerInfo() OwnerInfo {
	return OwnerInfo{
		Name:     "reverance",
		GitHub:   "https://github.com/itsreverance",
		Telegram: "t.me/itsreverance",
		Discord:  "@itsreverance",
		Website:  "not here yet",
		Email:    "reverance@proton.me",
	}
}

// ShowOwner displays owner information
func ShowOwner(conn net.Conn) {
	owner := GetOwnerInfo()

	conn.Write([]byte("\n"))
	conn.Write([]byte("╔══════════════════════════════════════════════════════════════╗\n"))
	conn.Write([]byte("║                         owner info                           ║\n"))
	conn.Write([]byte("╠══════════════════════════════════════════════════════════════╣\n"))
	conn.Write([]byte("║                                                              ║\n"))
	conn.Write([]byte("║  Name:      " + owner.Name + "\n"))
	conn.Write([]byte("║  GitHub:    " + owner.GitHub + "\n"))
	conn.Write([]byte("╚══════════════════════════════════════════════════════════════╝\n"))
	conn.Write([]byte("\n"))
}

// ShowOwnerSimple displays owner information without box
func ShowOwnerSimple(conn net.Conn) {
	owner := GetOwnerInfo()

	conn.Write([]byte("\n"))
	conn.Write([]byte("Name:     " + owner.Name + "\n"))
	conn.Write([]byte("GitHub:   " + owner.GitHub + "\n"))
	conn.Write([]byte("Telegram: " + owner.Telegram + "\n"))
	conn.Write([]byte("Discord:  " + owner.Discord + "\n"))
	conn.Write([]byte("Website:  " + owner.Website + "\n"))
	conn.Write([]byte("Email:    " + owner.Email + "\n"))
	conn.Write([]byte("\n"))
}