package handlers

import (
	"fmt"
	"net"
	"strconv"
	"strings"
	"time"
)

// ScanResult holds scan results for a single IP
type ScanResult struct {
	IP     string
	Port   int
	Open   bool
	Banner string
	Service string
}

// Common ports to scan
var CommonPorts = map[int]string{
	21:    "FTP",
	22:    "SSH",
	23:    "Telnet",
	25:    "SMTP",
	53:    "DNS",
	80:    "HTTP",
	110:   "POP3",
	111:   "RPC",
	135:   "MSRPC",
	139:   "NetBIOS",
	143:   "IMAP",
	443:   "HTTPS",
	445:   "SMB",
	993:   "IMAPS",
	995:   "POP3S",
	1723:  "PPTP",
	3306:  "MySQL",
	3389:  "RDP",
	5432:  "PostgreSQL",
	5900:  "VNC",
	6379:  "Redis",
	8080:  "HTTP-Alt",
	8443:  "HTTPS-Alt",
	27017: "MongoDB",
}

// ScanIP scans a single IP for open ports
func ScanIP(ip string, ports []int, timeout int) []ScanResult {
	var results []ScanResult

	for _, port := range ports {
		conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", ip, port), time.Duration(timeout)*time.Second)
		if err == nil {
			service := CommonPorts[port]
			if service == "" {
				service = "Unknown"
			}

			// Try to read banner
			banner := ""
			conn.SetReadDeadline(time.Now().Add(2 * time.Second))
			buf := make([]byte, 256)
			n, _ := conn.Read(buf)
			if n > 0 {
				banner = string(buf[:n])
				banner = strings.TrimSpace(banner)
			}
			conn.Close()

			results = append(results, ScanResult{
				IP:      ip,
				Port:    port,
				Open:    true,
				Banner:  banner,
				Service: service,
			})
		}
	}

	return results
}

// ScanNetwork scans a range of IPs
func ScanNetwork(ipRange string, ports []int, timeout int) []ScanResult {
	var results []ScanResult

	// Parse IP range (supports CIDR)
	var ips []string
	if strings.Contains(ipRange, "/") {
		// CIDR notation
		_, ipnet, err := net.ParseCIDR(ipRange)
		if err != nil {
			return results
		}
		for ip := ipnet.IP.Mask(ipnet.Mask); ipnet.Contains(ip); incIP(ip) {
			ips = append(ips, ip.String())
		}
	} else {
		// Single IP
		ips = append(ips, ipRange)
	}

	for _, ip := range ips {
		result := ScanIP(ip, ports, timeout)
		results = append(results, result...)
	}

	return results
}

// incIP increments an IP address
func incIP(ip net.IP) {
	for j := len(ip) - 1; j >= 0; j-- {
		ip[j]++
		if ip[j] > 0 {
			break
		}
	}
}

// ShowScanResults displays scan results
func ShowScanResults(conn net.Conn, results []ScanResult) {
	if len(results) == 0 {
		conn.Write([]byte("\nNo open ports found.\n\n"))
		return
	}

	openCount := 0
	for _, r := range results {
		if r.Open {
			openCount++
		}
	}

	conn.Write([]byte(fmt.Sprintf("\nScan complete. %d open ports found.\n", openCount)))
	conn.Write([]byte("\n"))
	conn.Write([]byte("IP               Port  Service    Banner\n"))
	conn.Write([]byte("------------------------------------------------------------\n"))

	for _, r := range results {
		if !r.Open {
			continue
		}
		banner := r.Banner
		if len(banner) > 30 {
			banner = banner[:27] + "..."
		}
		if banner == "" {
			banner = "-"
		}
		conn.Write([]byte(fmt.Sprintf("%-16s %-5d %-10s %s\n", r.IP, r.Port, r.Service, banner)))
	}

	conn.Write([]byte("\n"))
}

// StartScan performs a scan and shows results
func StartScan(conn net.Conn, ipRange string) {
	ShowInfo(conn, "Scanning "+ipRange+"...")

	// Default ports to scan
	ports := []int{21, 22, 23, 25, 53, 80, 443, 8080, 3306, 5432, 6379, 5900, 3389}

	results := ScanNetwork(ipRange, ports, 2)
	ShowScanResults(conn, results)
}

// ShowScanHelp displays scan usage
func ShowScanHelp(conn net.Conn) {
	conn.Write([]byte("\n"))
	conn.Write([]byte("scan <ip>          - Scan single IP\n"))
	conn.Write([]byte("scan <range>       - Scan CIDR range (e.g. scan 192.168.1.0/24)\n"))
	conn.Write([]byte("scan <ip> <ports>  - Scan specific ports (e.g. scan 8.8.8.8 22,80,443)\n"))
	conn.Write([]byte("\n"))
}

// ParsePorts parses a port list string (e.g. "22,80,443")
func ParsePorts(portStr string) []int {
	var ports []int
	parts := strings.Split(portStr, ",")
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if port, err := strconv.Atoi(p); err == nil && port > 0 && port < 65536 {
			ports = append(ports, port)
		}
	}
	return ports
}

// GetDefaultPorts returns the default port list
func GetDefaultPorts() []int {
	ports := make([]int, 0, len(CommonPorts))
	for p := range CommonPorts {
		ports = append(ports, p)
	}
	return ports
}