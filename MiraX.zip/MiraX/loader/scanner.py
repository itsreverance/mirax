#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import socket
import ipaddress
import threading
import time
from concurrent.futures import ThreadPoolExecutor

class Scanner:
    def __init__(self, timeout=2, threads=100):
        self.timeout = timeout
        self.threads = threads
        self.open_ports = {}

    def scan_port(self, ip, port):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self.timeout)
            result = sock.connect_ex((ip, port))
            sock.close()
            return result == 0
        except:
            return False

    def scan_ip(self, ip):
        ports = [23, 22, 21, 80, 443, 8080, 8443, 3306, 5432, 6379, 5900, 3389, 27017]
        open_ports = []
        for port in ports:
            if self.scan_port(ip, port):
                open_ports.append(port)
        return open_ports

    def scan_network(self, network):
        targets = []
        try:
            net = ipaddress.ip_network(network, strict=False)
            for ip in net.hosts():
                targets.append(str(ip))
        except:
            pass
        return targets

    def scan_targets(self, targets):
        results = {}
        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            futures = {executor.submit(self.scan_ip, target): target for target in targets}
            for future in futures:
                target = futures[future]
                try:
                    open_ports = future.result(timeout=10)
                    if open_ports:
                        results[target] = open_ports
                except:
                    pass
        return results